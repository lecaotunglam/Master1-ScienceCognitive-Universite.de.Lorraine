class Monkey:
    """A monkey."""
    
    # Write your code here
    pass
