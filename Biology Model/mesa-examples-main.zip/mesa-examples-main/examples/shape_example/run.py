from shape_example.server import server

server.launch()
