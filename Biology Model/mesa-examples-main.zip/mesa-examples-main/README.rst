# mesa-examples

This repository contains examples that work with Mesa and illustrate different features of Mesa. 

To contribute to this repository, see `CONTRIBUTING.rst`_

.. _`CONTRIBUTING.rst` : https://github.com/projectmesa/mesa-examples/blob/main/CONTRIBUTING.rst
